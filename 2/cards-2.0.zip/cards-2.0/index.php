<html>
 <head>
 <meta charset="UTF-8">
 <title>
 Sign-in form
 </title>
 </head>
 <body>
 <h1>Sign in to Cards application</h1>
 <table>
 <form action="login.php" method="post">
 <tr>
 <td>Username
 </td>
 <td><input name="username" type="text">
 </td>
 </tr>
 <tr>
 <td>Password
 </td>
 <td><input name="password" type="password">
 </td>
 <tr>
 <td>
 </td>
 <td><input type="submit" name="login" value="Login">
 </td>
 </tr>
 </form>
 </table>
 </body>
</html>

